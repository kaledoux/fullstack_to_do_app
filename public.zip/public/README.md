This project was built using the provided HTML templates and provided CSS stylesheets. I leveraged Handlebars templates but used Vanilla JS to complete all operations.

TEMPLATES:
The templates in use have been slightly modified from the originals provided by LS. In most cases, this means the addition of certain attributes to specific elements (data-*, ids, classes) that are then used within the application for searches etc.
Assumption: modification of the provided templates and reordering of portions of the layout is acceptable.
